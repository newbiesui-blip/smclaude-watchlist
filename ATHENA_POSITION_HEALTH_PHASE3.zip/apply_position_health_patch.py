from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
scanner = ROOT / "smc_scanner.py"
if not scanner.exists():
    raise SystemExit("Place this patcher beside the production smc_scanner.py")

s = scanner.read_text(encoding="utf-8")
backup = scanner.with_suffix(scanner.suffix + ".pre_health.bak")
shutil.copy2(scanner, backup)

# Import additive health engine.
if "import position_health" not in s:
    s = s.replace("import requests\n", "import requests\n\nimport position_health\n", 1)

# New-entry schema.
if '"position_health_state": None' not in s:
    anchor = '        "exchange_partial_close_detected": False,\n        "history": [],\n'
    if anchor not in s:
        raise SystemExit("Could not find watchlist schema anchor")
    replacement = '''        "exchange_partial_close_detected": False,
        "position_health_state": None,
        "position_health_previous_state": None,
        "position_health_reason": None,
        "position_health_updated_at": None,
        "position_health_risk_score": 0,
        "position_health_derivatives_state": "NEUTRAL",
        "position_health_derivatives_score": 0.0,
        "position_health_transition": False,
        "history": [],
'''
    s = s.replace(anchor, replacement, 1)

# Legacy schema backfill.
if 'it.setdefault("position_health_state"' not in s:
    anchor = '        it.setdefault("exchange_partial_close_detected", False)\n'
    if anchor not in s:
        raise SystemExit("Could not find legacy schema anchor")
    replacement = '''        it.setdefault("exchange_partial_close_detected", False)
        it.setdefault("position_health_state", None)
        it.setdefault("position_health_previous_state", None)
        it.setdefault("position_health_reason", None)
        it.setdefault("position_health_updated_at", None)
        it.setdefault("position_health_risk_score", 0)
        it.setdefault("position_health_derivatives_state", "NEUTRAL")
        it.setdefault("position_health_derivatives_score", 0.0)
        it.setdefault("position_health_transition", False)
'''
    s = s.replace(anchor, replacement, 1)

# Health evaluation must happen after the fresh SMC reversal diagnostic and only
# after BingX has confirmed OPEN. Do not alter any SMC decision fields.
if "POSITION HEALTH: additive intelligence only" not in s:
    anchor = '''        reversal_state, reversal_reason, _reversal_level = _position_reversal_diagnostic(tf_results, direction)
        previous_reversal_state = entry.get("reversal_state", "STABLE")
        entry["reversal_state"] = reversal_state
        entry["reversal_reason"] = reversal_reason
'''
    if anchor not in s:
        raise SystemExit("Could not find reversal diagnostic anchor")
    replacement = anchor + '''
        # POSITION HEALTH: additive intelligence only. It cannot change SMC score,
        # direction, entry, stop, targets, execution state, or trade classification.
        # Active health is allowed only when BingX has already confirmed OPEN.
        if str(entry.get("exchange_sync_status", "")).upper() == "OPEN":
            derivatives_context = position_health.get_derivatives_context(symbol)
            health_snapshot, health_transition = position_health.apply_health(
                entry, derivatives_context
            )
            if health_snapshot.get("active"):
                entry["position_health_transition"] = bool(health_transition)
                if health_transition:
                    _log(entry, f"Position health: {health_snapshot['health_state']} | {health_snapshot['reason']}")
'''
    s = s.replace(anchor, replacement, 1)

# Transition-only notifier.
if "def _notify_position_health_transition" not in s:
    anchor = "def _notify_score_update(entry):\n"
    if anchor not in s:
        raise SystemExit("Could not find score notifier anchor")
    replacement = '''def _notify_position_health_transition(entry):
    """Alert only on a position-health state transition. Never a new entry."""
    if not TELEGRAM_ENABLED or not entry.get("position_health_transition"):
        return
    if str(entry.get("exchange_sync_status", "")).upper() != "OPEN":
        return
    symbol = entry["symbol"]
    direction = entry["direction"]
    trade_type = entry.get("trade_type", "INTRADAY")
    previous = entry.get("position_health_previous_state") or "INITIAL"
    current = entry.get("position_health_state") or "UNKNOWN"
    emoji = {
        "HEALTHY": "🟢",
        "CAUTION": "🟡",
        "ELEVATED_RISK": "🟠",
        "EXIT_WARNING": "🔴",
        "RECOVERY": "🔵",
    }.get(current, "⚠️")
    lines = [
        f"{emoji} POSITION HEALTH TRANSITION: {symbol} {direction} [{trade_type}]",
        f"Health: {previous} → {current}",
        f"Current R: {entry.get('current_r', 0.0):+.2f}R | Max R: {entry.get('max_r', 0.0):+.2f}R",
        f"SMC: {entry.get('reversal_state', 'STABLE')}",
        f"Derivatives: {entry.get('position_health_derivatives_state', 'NEUTRAL')} ({entry.get('position_health_derivatives_score', 0.0):+.1f})",
        f"Why: {entry.get('position_health_reason', '')}",
        "Confirmed BingX OPEN position only -- NOT a new entry signal.",
    ]
    if current == "EXIT_WARNING":
        lines.append("Action: PROTECT / REVIEW EXIT NOW. ATHENA does not execute orders.")
    elif current == "ELEVATED_RISK":
        lines.append("Action: ELEVATED RISK -- protect position and monitor closely.")
    elif current == "CAUTION":
        lines.append("Action: CAUTION -- thesis is weakening; monitor the next confirmation.")
    elif current == "RECOVERY":
        lines.append("Action: CONDITIONS IMPROVING -- recovery, not a new entry signal.")
    send_telegram_message("\\n".join(lines))


def _notify_score_update(entry):
'''
    s = s.replace(anchor, replacement, 1)

# Notify health transition before the existing active update. Clear the one-cycle flag after use.
if "_notify_position_health_transition(it)" not in s:
    anchor = '''            elif it["status"] == "triggered":
                _notify_score_update(it)
'''
    if anchor not in s:
        raise SystemExit("Could not find check_watchlist notifier anchor")
    replacement = '''            elif it["status"] == "triggered":
                _notify_position_health_transition(it)
                _notify_score_update(it)
                it["position_health_transition"] = False
'''
    s = s.replace(anchor, replacement, 1)

scanner.write_text(s, encoding="utf-8")
print(f"Patched {scanner}")
print(f"Backup: {backup}")
